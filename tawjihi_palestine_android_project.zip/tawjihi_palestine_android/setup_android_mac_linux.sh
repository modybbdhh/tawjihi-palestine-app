#!/usr/bin/env bash
set -e
command -v npm >/dev/null 2>&1 || { echo "Install Node.js LTS/npm first."; exit 1; }
npm install
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
npx cap open android
