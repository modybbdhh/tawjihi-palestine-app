# توجيهي فلسطين — مشروع أندرويد (Capacitor)

هذا المشروع يغلّف النموذج الأولي الموجود في `www/` داخل تطبيق Android باستخدام Capacitor.
**هذا مجلد مصدر وليس ملف APK جاهزًا**؛ يجب بناء APK على جهاز كمبيوتر عليه Android Studio وAndroid SDK.

## المتطلبات
- كمبيوتر Windows أو macOS أو Linux.
- Node.js LTS وnpm.
- Android Studio مع Android SDK وBuild Tools.
- اتصال بالإنترنت أثناء تثبيت حزم npm لأول مرة.

## خطوات بناء APK

1. فك ضغط `tawjihi_palestine_android.zip`.
2. افتح Terminal أو PowerShell داخل مجلد `tawjihi_palestine_android`.
3. نفّذ الأوامر التالية بالترتيب:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

4. سيفتح المشروع في Android Studio. انتظر انتهاء Gradle Sync وثبّت أي SDK يطلبه Android Studio.
5. لتجربة التطبيق على هاتفك:
   - فعّل Developer options وUSB debugging على هاتف أندرويد.
   - وصّل الهاتف بالكمبيوتر عبر USB ووافق على رسالة السماح.
   - من Android Studio اضغط Run ▶️ لاختباره.
6. لإنشاء ملف APK:
   - من قائمة Android Studio اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - بعد اكتمال البناء اضغط **locate** من الإشعار لفتح مكان الملف.
   - غالبًا سيكون في `android/app/build/outputs/apk/debug/app-debug.apk`.
7. انقل `app-debug.apk` إلى الهاتف وافتحه للتثبيت. قد تحتاج السماح بالتثبيت من هذا المصدر في إعدادات أندرويد.

## تحديث واجهة التطبيق لاحقًا
بعد تعديل ملفات `www/` نفّذ:

```bash
npx cap sync android
```

ثم أعد البناء في Android Studio.

## ما الذي يتضمنه النموذج؟
- واجهة عربية RTL متجاوبة.
- مواد وملخصات تجريبية.
- اختبار قصير مع تصحيح وتفسير.
- حفظ التقدم في تخزين المتصفح المحلي على الجهاز.
- نموذج اسم محلي ومساعد بردود تجريبية.

## ما الذي لا يزال غير مكتمل؟
- لا توجد حسابات حقيقية أو قاعدة بيانات أو مزامنة بين الأجهزة.
- المساعد ليس متصلًا بخدمة ذكاء اصطناعي حقيقية.
- الملخصات أمثلة فقط وليست مكتبة PDF كاملة للمنهاج.
- لا يوجد APK مبني داخل هذا الملف؛ إنشاء APK يحتاج Android Studio/SDK. لا يمكن بناء نسخة أندرويد نهائية موثوقة من ملفات المصدر وحدها دون بيئة بناء أندرويد.
- لا تضع مفاتيح API في `www/`؛ استخدم خادمًا آمنًا إذا أضفت خدمة ذكاء اصطناعي.
