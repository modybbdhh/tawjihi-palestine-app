@echo off
chcp 65001 >nul
echo === إعداد مشروع توجيهي فلسطين ===
where npm >nul 2>nul
if errorlevel 1 (
  echo لم يتم العثور على Node.js/npm. ثبّت Node.js LTS أولاً.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto error
if not exist android (
  call npx cap add android
  if errorlevel 1 goto error
)
call npx cap sync android
if errorlevel 1 goto error
call npx cap open android
goto end
:error
echo حدث خطأ. راجع الرسالة أعلاه وتأكد من الإنترنت وAndroid Studio.
pause
:end
